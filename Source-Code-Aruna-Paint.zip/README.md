# ArunaPaintProject
This is Aruna Interactive Device Paint Application

